
package schoolmanagementsystem;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ML
 */
public class SchoolManagementSystem {
 static ArrayList<Student> students = new ArrayList<>();
    static ArrayList<Teacher> teachers = new ArrayList<>();
    static Scanner scanner = new Scanner(System.in);
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         homepage();
    }
    
    public static void homepage() {
        System.out.println("**************************Welcome to School Management System***************************\n\n\n\n");
        System.out.println("1. Login\n2. Exit");
        int choice = scanner.nextInt();
        scanner.nextLine(); 
        if (choice == 1) {
            login();
        } else {
            System.out.println("Exiting...");
            System.exit(0);
        }
    }

    public static void login() {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

       
        if (username.equals("mahnoor") && password.equals("asd123")) {
            System.out.println("\n\n\n\nLogged in Successfully!!!! \n\n\n\n ");
            showMenu();
        } else {
            System.out.println("Invalid credentials. Try again.");
            login();
        }
    }

    public static void showMenu() {
        int choice;
        do {
            System.out.println("\nMain Menu");
            System.out.println("1. Student Module\n2. Teacher Module\n3. Logout");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1 -> studentMenu();
                case 2 -> teacherMenu();
                case 3 -> homepage();
                default -> System.out.println("Invalid choice. Try again.");
            }
        } while (choice != 3);
    }

    public static void studentMenu() {
        int choice;
        do {
            System.out.println("\nStudent Module");
            System.out.println("1. Add Student\n2. Update Student\n3. Delete Student\n4. View Students\n5. Back to Main Menu");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1 -> addStudent();
                case 2 -> updateStudent();
                case 3 -> deleteStudent();
                case 4 -> viewStudents();
                case 5 -> showMenu();
                default -> System.out.println("Invalid choice. Try again.");
            }
        } while (choice != 5);
    }

    public static void teacherMenu() {
        int choice;
        do {
            System.out.println("\nTeacher Module");
            System.out.println("1. Add Teacher\n2. Update Teacher\n3. Delete Teacher\n4. View Teachers\n5. Back to Main Menu");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1 -> addTeacher();
                case 2 -> updateTeacher();
                case 3 -> deleteTeacher();
                case 4 -> viewTeachers();
                case 5 -> showMenu();
                default -> System.out.println("Invalid choice. Try again.");
            }
        } while (choice != 5);
    }

    public static void addStudent() {
        System.out.print("Enter Student ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); 
        System.out.print("Enter Student Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Student Age: ");
        int age = scanner.nextInt();
        System.out.print("Enter Student GPA: ");
        float gpa = scanner.nextFloat();

        students.add(new Student(id, name, age, gpa));
        System.out.println("Student added successfully.");
    }

    public static void updateStudent() {
        System.out.print("Enter Student ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine(); 

        for (Student student : students) {
            if (student.id == id) {
                System.out.print("Enter new Student Name: ");
                student.name = scanner.nextLine();
                System.out.print("Enter new Student Age: ");
                student.age = scanner.nextInt();
                System.out.print("Enter new Student GPA: ");
                student.gpa = scanner.nextFloat();
                System.out.println("Student updated successfully.");
                return;
            }
        }
        System.out.println("Student not found.");
    }

    public static void deleteStudent() {
        System.out.print("Enter Student ID to delete: ");
        int id = scanner.nextInt();

        for (int i = 0; i < students.size(); i++) {
            if (students.get(i).id == id) {
                students.remove(i);
                System.out.println("Student deleted successfully.");
                return;
            }
        }
        System.out.println("Student not found.");
    }

    public static void viewStudents() {
        System.out.println("ID\tName\t\tAge\tGPA");
        for (Student student : students) {
            System.out.printf("%d\t%s\t\t%d\t%.2f\n", student.id, student.name, student.age, student.gpa);
        }
    }

    public static void addTeacher() {
        System.out.print("Enter Teacher ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); 
        System.out.print("Enter Teacher Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Teacher Age: ");
        int age = scanner.nextInt();
        scanner.nextLine(); 
        System.out.print("Enter Teacher Subject: ");
        String subject = scanner.nextLine();

        teachers.add(new Teacher(id, name, age, subject));
        System.out.println("Teacher added successfully.");
    }

    public static void updateTeacher() {
        System.out.print("Enter Teacher ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine(); 

        for (Teacher teacher : teachers) {
            if (teacher.id == id) {
                System.out.print("Enter new Teacher Name: ");
                teacher.name = scanner.nextLine();
                System.out.print("Enter new Teacher Age: ");
                teacher.age = scanner.nextInt();
                scanner.nextLine(); 
                System.out.print("Enter new Teacher Subject: ");
                teacher.subject = scanner.nextLine();
                System.out.println("Teacher updated successfully.");
                return;
            }
        }
        System.out.println("Teacher not found.");
    }

    public static void deleteTeacher() {
        System.out.print("Enter Teacher ID to delete: ");
        int id = scanner.nextInt();

        for (int i = 0; i < teachers.size(); i++) {
            if (teachers.get(i).id == id) {
                teachers.remove(i);
                System.out.println("Teacher deleted successfully.");
                return;
            }
        }
        System.out.println("Teacher not found.");
    }

    public static void viewTeachers() {
        System.out.println("ID\tName\t\tAge\tSubject");
        for (Teacher teacher : teachers) {
            System.out.printf("%d\t%s\t\t%d\t%s\n", teacher.id, teacher.name, teacher.age, teacher.subject);
        }
    }
}
    

